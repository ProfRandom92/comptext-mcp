.venv\Scripts\python.exe -c "import comptext_mcp; print('comptext-mcp import ok')"
