import inspect
import subprocess

from comptext_mcp import runner


def test_runner_uses_shell_false() -> None:
    source = inspect.getsource(runner.run_command)
    assert "shell=False" in source
    assert "shell=True" not in source
