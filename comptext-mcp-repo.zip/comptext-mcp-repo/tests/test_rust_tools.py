from comptext_mcp.rust_tools import rust_audit


def test_rust_audit_command_shapes(monkeypatch) -> None:
    seen = []

    def fake_try_command(args, cwd=None):
        seen.append(args)
        return {"args": args, "returncode": 0, "stdout": "", "stderr": ""}

    monkeypatch.setattr("comptext_mcp.rust_tools.try_command", fake_try_command)
    rust_audit(check=True, clippy=True, tests_no_run=True)
    assert ["cargo", "test", "--workspace", "--no-run"] in seen
    assert not any(args[:2] == ["cargo", "run"] for args in seen)
