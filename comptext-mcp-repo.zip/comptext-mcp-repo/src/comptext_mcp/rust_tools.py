from __future__ import annotations

from typing import Any

from .policy import assert_safe_cargo_args
from .runner import try_command, workspace


def rust_versions() -> dict[str, Any]:
    return {
        "rustc": try_command(["rustc", "--version"]),
        "cargo": try_command(["cargo", "--version"]),
    }


def cargo_metadata() -> dict[str, Any]:
    args = ["cargo", "metadata", "--no-deps", "--format-version", "1"]
    assert_safe_cargo_args(args)
    return try_command(args, cwd=workspace())


def rust_audit(check: bool = True, clippy: bool = False, tests_no_run: bool = True) -> dict[str, Any]:
    commands: list[list[str]] = [["cargo", "metadata", "--no-deps", "--format-version", "1"]]
    if check:
        commands.append(["cargo", "check", "--workspace"])
    if tests_no_run:
        commands.append(["cargo", "test", "--workspace", "--no-run"])
    if clippy:
        commands.append(["cargo", "clippy", "--workspace", "--", "-D", "warnings"])

    results = []
    for args in commands:
        assert_safe_cargo_args(args)
        results.append(try_command(args, cwd=workspace()))

    return {"workspace": str(workspace()), "commands": commands, "results": results}
