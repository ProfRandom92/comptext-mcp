"""Local GitHub packaging helpers.

Network operations are intentionally not implemented in v0.1.0.
"""
